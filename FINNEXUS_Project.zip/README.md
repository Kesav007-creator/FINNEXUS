# FINNEXUS — Real-Time Fraud & AML Risk Orchestration Platform

> **Enterprise Compliance Console** inspired by NICE Actimize (ActOne / AMLOCK), Feedzai, Sardine, and FraudNet.

---

## 🚀 Quick Start (Run on any computer in 10 seconds)

### Method A: One-Click Launcher
- **Windows**: Double-click `run.bat`
- **Mac / Linux**: Open Terminal and run `./run.sh`

---

### Method B: Manual Command Line
1. **Install requirements**:
   ```bash
   pip install -r requirements.txt
   ```
2. **Launch FINNEXUS**:
   ```bash
   streamlit run app.py
   ```
3. Open your browser at `http://localhost:8501`.

---

## 📦 What's Included in this Package

| File / Folder | Purpose |
|---|---|
| `app.py` | Complete single-file production prototype with all modules, graphs, and simulation engines |
| `.streamlit/config.toml` | Ensures crisp enterprise light theme and contrast across all operating systems and browsers |
| `requirements.txt` | Core packages: `streamlit`, `pandas`, `networkx` |
| `run.bat` | 1-click Windows launcher (installs packages and opens browser automatically) |
| `run.sh` | 1-click Mac / Linux bash launcher |

---

## 🛡️ Key Platform Modules to Demo

1. **Exact Alert Cards & SVG Score Meter**:
   - Header banner with Priority pill (`P1 - CRITICAL`), plain-English summary, and bold risk score number.
   - Amazon-style sequential tracking timeline: `[Received] ── [Scored] ── (Flagged) ── [Reviewed] ── [Action Taken]`.
   - Semi-circular SVG **Risk Rating Score Meter / Speedometer Gauge** with needle pointing to score.
   - 1-Click Orchestration buttons: `Approve`, `Hold & Send OTP` (friction reduction), and `Freeze Account`.

2. **"More details" Deep Case Dossier**:
   - Click **"More details"** on any alert to view:
     - **Key account details for EVERYONE involved** (all 4–5 accounts, KYC tiers, roles, device tokens, geolocations, IP).
     - **Autonomous AI Investigator Analysis** with clear compliance directive.
     - **Feedzai Whitebox Explanations** with 5-dot severity indicators (`●●●●●`).
     - **NICE Actimize Cross-Channel Risk Correlations** (Wire, ACH, Device Token, Tor Relay).
     - Complete granular transaction ledger.

3. **Multi-Criteria Filtering & Sorter**:
   - Sort alerts by **Risk Score (Highest to Lowest)**, **Entities Involved (Largest Rings First)**, **Cluster Exposure ($)**, or **Newest Ingestion**.
   - Filter by Priority or Status.
   - Click `➕ Ingest Live Transaction` to simulate inbound real-time transaction streams.

4. **NetworkX AML Circular Loop Detector (Killer USP)**:
   - Dynamic `nx.simple_cycles()` detector mapping multi-account circular layering rings (e.g. `Alice → Bob → Charlie → Diana → Alice`).
   - Native SVG **Genome Network Graph Visualizer** with glowing loop nodes.
   - Feedzai **Similar Geometries** pattern matching (Circular Layering 96.4%, CTR Smurfing 89.1%, Mule Token 81.5%).
   - Sardine **Mod Z-Score Telemetry** (+4.8 Timezone Jump, +5.1 Velocity Spike).

5. **Stationary Right Panel + AI Copilot Chatbot**:
   - As you scroll through alerts on the left, the right intelligence panel stays stationary.
   - Interactive **FINNEXUS AI Copilot Chatbot** in the right panel and floating button at bottom-right corner.
   - Click quick prompts (`💬 Explain Ring #1`, `💬 Check Structuring`) or type custom AML questions.

6. **Permanent Audit Log & Multi-Tab Views**:
   - Immutable audit trail at the bottom logging every analyst action.
   - Top tabs: `Alert Orchestrator`, `Executive Dashboard`, `Case Management (ActOne)`, and `FinCEN SAR Filings`.
